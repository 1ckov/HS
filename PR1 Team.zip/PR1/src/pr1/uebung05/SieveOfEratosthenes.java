package pr1.uebung05;

import static pr.MakeItSimple.*;

public class SieveOfEratosthenes {

	public static void main(String[] args) {
		println("Geben Sie eine Zahl N an: ");
		int zahl = readInt();
		if (zahl < 2) {
			println("Bitte keine Zahl kleiner als 2 eingeben!");
		} else {
			boolean[] primzahlenArray = calculatePrimes(zahl);
			for (int i = 1; i < primzahlenArray.length; i++) {
				println("Position: " + i + " primzahl: " + primzahlenArray[i]);
			}
		}
	}

	public static boolean[] calculatePrimes(int zahl) {
		boolean[] primzahlenArray = new boolean[zahl + 1];

		for (int i = 2; i < primzahlenArray.length; i++) {
			primzahlenArray[i] = true;
		}

		for (int i = 2; i < primzahlenArray.length; i++) {

			for (int k = 2; k <= i; k++) {
				int position = k * i;
				if (position < primzahlenArray.length) {
					primzahlenArray[position] = false;
				}

			}

		}

		return primzahlenArray;
	}

}
