package pr1.uebung09;

import static pr.MakeItSimple.*;

public class LinearListWithArray {
	private int[] liste;
	
	public LinearListWithArray(){
		this.liste = new int[0];
		
		
	}
	
	void addFirst(int zahl){
		
		if(this.liste.length == 0){
			this.liste = new int[1];
			this.liste[0] = zahl;
		}
		else{
			int[] hilfsArray = new int[liste.length + 1];
			hilfsArray[0] = zahl;
			
			for(int i = 1; i < hilfsArray.length; i++){
				hilfsArray[i] = liste[i - 1];
			}
			liste = hilfsArray;
		}
		
		
	}
	
	void addLast(int zahl){
		
		if(this.liste.length == 0){
			this.liste = new int[1];
			this.liste[0] = zahl;
		}
		else{
			int[] hilfsArray = new int[liste.length + 1];
			hilfsArray[liste.length] = zahl;
			
			for(int i = 0; i < liste.length; i++){
				hilfsArray[i] = liste[i];
			}
			liste = hilfsArray;
		}
		
		
	}
	
	
	int getFirst(){
		if(this.liste.length == 0){
			throw new PRException("Liste ist leer");
		}else{
			return liste[0];	
		}
		
		
	}
	
	
	int getLast(){
		if(this.liste.length == 0){
			throw new PRException("Liste ist leer");
		}else{
			return liste[liste.length - 1];	
		}
		
		
	}
	
	int getAt(int position){
		if(this.liste.length <= position){
			throw new PRException("Liste hat nicht genügend Elemente");
		}
		else if(position < 0){
			throw new PRException("keine negativen Zahlen");
		}
		return liste[position];
	}
		
		
	
	
	void removeFirst(){
		if(this.liste.length == 0){
			throw new PRException("Liste ist leer");
		}
		int[] hilfsArray = new int[liste.length - 1];
		for(int i = 0; i < hilfsArray.length; i++){
			hilfsArray[i] = liste[i+1];
		}
		liste = hilfsArray;
	}
	
	boolean contains(int zahl){
		
		for(int i = 0; i < liste.length; i++){
			if(liste[i] == zahl){
				return true;
			}
		}
		
		
		return false;
	}
	//257
	void delete(int zahl){
		if(this.liste.length == 0){
			throw new PRException("Liste ist leer");
		}
		
		int firstPosition = -1;
		int i = 0;
		while(i < liste.length && firstPosition==-1){
			if(liste[i] == zahl){
				firstPosition = i;
				
			}
			i++;
		}
		int[] hilfsArray = new int[liste.length - 1];
		if(firstPosition!=-1){
			for(int k = 0; k < firstPosition; k++){
				hilfsArray[k] = liste[k];
			}
			for(int j = firstPosition; j < hilfsArray.length; j++){
				hilfsArray[j] = liste[j+1];
			}
			liste = hilfsArray;
		}
		
	}
	
	void clear(){
		this.liste = new int[0];
	}
	
	boolean isEmpty(){
		return !(this.liste.length > 0);
	}
	int size(){
		return this.liste.length;
	}
	
	public LinearListWithArray clone(){
		LinearListWithArray clone = new LinearListWithArray();
		clone.liste = new int[this.liste.length];
		for(int i = 0; i<this.liste.length; i++){
			clone.liste[i] = this.liste[i];
		}
		return clone;
		
	}
	
	LinearListWithArray empty(){
		LinearListWithArray liste = new LinearListWithArray();
		return liste;
	}
	
	public static void main(String[] args) {
		LinearListWithArray list = new LinearListWithArray();
		list.addFirst(3);
		list.addFirst(2);
		list.addLast(4);
		list.addFirst(1);
		LinearListWithArray list2 = list.clone();
		//list.delete(2);
		//list.clear();
		println(list.size());
		for(int i = 0; i < list2.liste.length; i++){
			println(list2.liste[i]);
		}
	}
	
}
