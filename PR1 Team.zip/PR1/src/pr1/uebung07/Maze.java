package pr1.uebung07;

import static pr.MakeItSimple.*;

public class Maze {

	public static void main(String[] args) {
		char[][] lab = new char[][] {
			"## #######".toCharArray(),
			"#        #".toCharArray(),
			"## #######".toCharArray(),
			"#   #    #".toCharArray(),
			"##### ## S".toCharArray(),
			"#   # ####".toCharArray(),
			"# # #     ".toCharArray(),
			"# # #### #".toCharArray(),
			"# #      #".toCharArray(),
			"# ########".toCharArray(),
		};

		int[] Startposition = new int[2];
		Startposition = findStartposition(lab);
		for (int i = 0; i < Startposition.length; i++) {
			println(Startposition[i] + ",");
		}

		findWay(lab);
		for (int row = 0; row < lab.length; row++) {
			for (int col = 0; col < lab[0].length; col++)
				print("" + lab[row][col]);
			println();
		}

	}

	static void findWay(char[][] field) {
		int[] Startposition = new int[2];
		Startposition = findStartposition(field);
		findWayRecursive(field, Startposition[1], Startposition[0]);

	}

	static boolean findWayRecursive(char[][] field, int row, int col) {
		if (mazeSolved(field, row, col)) {
			field[row][col] = 'E';
			return true;
		}

		if (canMove(field, row - 1, col)) {
			println("canMoveoben");
			addPoint(field, row, col);
			if (findWayRecursive(field, row - 1, col)) {
				return true;
			}
		} else if (canMove(field, row, col - 1)) {
			println("canMovelinks");
			addPoint(field, row, col);
			if (findWayRecursive(field, row, col - 1)) {
				return true;
			}
		}

		else if (canMove(field, row + 1, col)) {
			println("canMoveunten");
			addPoint(field, row, col);
			if (findWayRecursive(field, row + 1, col)) {
				return true;
			}
		}

		else if (canMove(field, row, col + 1)) {
			println("canMoverechts");
			addPoint(field, row, col);
			if (findWayRecursive(field, row, col + 1)) {
				return true;
			}
		}

		else {
			goBack(field, row, col);
		}

		return false;
	}

	static void goBack(char[][] field, int row, int col) {
		field[row][col] = ' ';
		boolean cameFromAbove = false;
		boolean cameFromBelow = false;
		boolean cameFromRight = false;
		boolean cameFromLeft = false;
		if (row < field.length - 1 && col < field[0].length - 1) {
			if (field[row + 1][col] == '.') {
				row = row + 1;
				cameFromBelow = true;
			} else if (field[row - 1][col] == '.') {
				row = row - 1;
				cameFromAbove = true;
			} else if (field[row][col + 1] == '.') {
				col = col + 1;
				cameFromLeft = true;
			} else if (field[row][col - 1] == '.') {
				col = col - 1;
				cameFromRight = true;
			}
		}

		if ((field[row + 1][col] == ' ' && field[row - 1][col] == ' ')
				|| (field[row + 1][col] == ' ' && field[row][col + 1] == ' ')
				|| (field[row + 1][col] == ' ' && field[row][col - 1] == ' ')
				|| (field[row - 1][col] == ' ' && field[row][col + 1] == ' ')
				|| (field[row - 1][col] == ' ' && field[row][col - 1] == ' ')
				|| (field[row][col + 1] == ' ' && field[row][col - 1] == ' ')) {

			if (cameFromBelow) {
				if (canMove(field, row, col + 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col + 1);
				} else if (canMove(field, row - 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row - 1, col);
				} else if (canMove(field, row, col - 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col - 1);
				}

			}

			if (cameFromAbove) {
				if (canMove(field, row, col - 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col - 1);
				} else if (canMove(field, row + 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row - 1, col);
				} else if (canMove(field, row, col + 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col + 1);
				}

			}
			if (cameFromRight) {
				if (canMove(field, row - 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row - 1, col);
				} else if (canMove(field, row, col - 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col - 1);
				} else if (canMove(field, row + 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row + 1, col);
				}

			}

			if (cameFromLeft) {
				if (canMove(field, row + 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row + 1, col);
				} else if (canMove(field, row, col + 1)) {
					addPoint(field, row, col);
					findWayRecursive(field, row, col + 1);
				} else if (canMove(field, row - 1, col)) {
					addPoint(field, row, col);
					findWayRecursive(field, row - 1, col);
				}

			}

		} else {
			goBack(field, row, col);
		}
	}

	public static boolean mazeSolved(char[][] field, int row, int col) {
		return ((row == 0 || col == 0 || row == 9 || col == 9) && field[row][col] != 'S');

	}

	public static boolean canMove(char[][] field, int row, int col) {
		if (row < field.length && col < field[0].length) {
			return !(field[row][col] == '#' || field[row][col] == '.' || field[row][col] == 'S');
		} else {
			return false;
		}

	}

	public static void addPoint(char[][] field, int row, int col) {
		field[row][col] = '.';

	}

	public static int[] findStartposition(char[][] field) {
		int[] Startposition = new int[2];
		for (int row = 0; row < field.length; row++) {
			for (int col = 0; col < field[0].length; col++)
				if (field[row][col] == 'S') {
					Startposition[0] = col;
					Startposition[1] = row;

				}
		}

		return Startposition;

	}

}
