package pr1.uebung07;

import static pr.MakeItSimple.*;

public class StringExtension {
	static String toUpper(String text) {
		
		char[] storage = text.toCharArray();
		int shift = 'A' - 'a';
		for (int position = 0; position < storage.length; position++) {
			if (((int) storage[position] >= (int) 'a' && (int) storage[position] <= (int) 'z')
					|| storage[position] == 'ä' || storage[position] == 'ö' || storage[position] == 'ü') {
				storage[position] = (char) ((int) storage[position] + shift);
			}
		}
		String textModified = new String(storage);
		return textModified;
	}
	
	static String toUpperRecursive(String text) {
		char[] storage = text.toCharArray();
		int position = 0;
		char[] charArrayToBeConverted = toUpperHelper(storage, position);
		String upperText = new String(charArrayToBeConverted);
		return upperText;
	}

	static char[] toUpperHelper(char[] storage, int position) {
		int shift = 'A' - 'a';
		if (position < storage.length) {
			if (storage[position] >= 'a' && storage[position] <= 'z') {
				storage[position] += shift;
				return toUpperHelper(storage, position + 1);
			} else
				return toUpperHelper(storage, position + 1);
		} else
			return storage;

	}
	static int scan(String text, String needle) {
		boolean isNeedleFound = false;
		int positionNeedle = 0;
		int firstPositionNeedleFound = 0;

		if (needle.equals("")) {
			throw new PRException("Es werden keine leeren Strings zugelassen!");
		} else {
			for (int position = 0; position < text.length(); position++) {

				if (positionNeedle < needle.length() && text.charAt(position) == needle.charAt(positionNeedle)) {
					positionNeedle++;
				}
				if (positionNeedle == needle.length() - 1) {
					isNeedleFound = true;
					firstPositionNeedleFound = (position + 2) - needle.length();
				}
			}
		}

		if (isNeedleFound) {
			return firstPositionNeedleFound;
		} else
			throw new PRException("Das gewünschte Element wurde nicht gefunden.");

	}
	public static String[] split(String text, char delimiter) {
		char[] textToChars = text.toCharArray();
		int counter = 1;
		for (int position = 0; position < textToChars.length; position++) {
			if (textToChars[position] == delimiter) {
				counter++;
			}
		}
		String storage = "";
		int positionText = 0;
		String[] splitedText = new String[counter];
		for (int position = 0; position < textToChars.length; position++) {
			if (textToChars[position] != delimiter) {
				storage += textToChars[position];
				splitedText[positionText] = storage;
			} else if (textToChars[position] == delimiter) {
				storage = "";
				positionText++;
			}

		}
		return splitedText;
	}

	public static void main(String[] args) {
		
		boolean showMenu = true;
		while (showMenu) {
			println("Wählen sie aus folgendem Menü");
			println("1  Verwendet die Methode toUpperCase auf Ihre Eingabe");
			println("2  Sucht Ihre Eingabe in einem größerem String");
			println("3  Teilt Ihren String auf");
			println("4  Programm Stoppen");
			int auswahl = readInt();
			
			switch (auswahl) {
			case 1:
				println("Ihre Nachricht: ");
				String text = readString();
				println(toUpperRecursive(text));
				break;
			case 2:
				println("Ihre Nachricht: ");
				String text2 = readString();
				println("Geben sie den Teil-String ein, nach dem gesucht werden soll");
				String needle = readString();
				println(scan(text2, needle));
				break;
			case 3:
				println("Ihre Nachricht: ");
				String text3 = readString();
				println("Geben sie ein Zeichen ein mit dem Ihre Nachricht geteilt werden soll");
				String character = readString();
				char[] delimeter = character.toCharArray();
				String[] splitedText = (split(text3, delimeter[0]));
				for (int position = 0; position < splitedText.length; position++) {
					println(splitedText[position]);
				}
				break;
				case 4:
					showMenu = false;
					break;
				}
			}
		}

	}


