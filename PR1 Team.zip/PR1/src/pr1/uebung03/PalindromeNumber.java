package pr1.uebung03;

import static pr.MakeItSimple.*;

public class PalindromeNumber {

	public static void main(String[] args) {

		println("Geben Sie eine beliebige ganze Zahl zwischen 0 und 2 Milliarden ein: ");
		int zahl = readInt();
		if (zahl > 2000000000 || zahl < 0) {
			print("Ungültige Eingabe");

		} else {
			int letzteZiffer;
			int anzahlZiffern = 0;

			if (zahl < 10) {
				anzahlZiffern = 1;
			} else if (zahl < 100) {
				anzahlZiffern = 2;
			} else if (zahl < 1000) {
				anzahlZiffern = 3;
			} else if (zahl < 10000) {
				anzahlZiffern = 4;
			} else if (zahl < 100000) {
				anzahlZiffern = 5;
			} else if (zahl < 1000000) {
				anzahlZiffern = 6;
			} else if (zahl < 10000000) {
				anzahlZiffern = 7;
			}
			int[] ziffernarray = new int[11];

			for (int i = 1; i <= anzahlZiffern; i++) {

				if (i == 1) {
					letzteZiffer = zahl % 10;
				} else {
					int divisor = 1;
					for (int j = 1; j < i; j++) {
						divisor *= 10;
					}
					letzteZiffer = (zahl / divisor) % 10;

				}
				ziffernarray[i] = letzteZiffer;

			}

			int countUngleiche = 0;
			if (anzahlZiffern == 1) {

			} else {

				for (int count = 1; count <= anzahlZiffern; count++) {

					if (count != ((anzahlZiffern / 2) + 1)) {
						int countVonHinten = anzahlZiffern - count + 1;
						if (ziffernarray[count] == ziffernarray[countVonHinten]) {

						} else {
							countUngleiche++;
						}
					}
				}
			}
			if (countUngleiche > 0) {
				println("Das ist kein Palindrom!");
			} else {
				println("Das ist ein Palindrom!");
			}

		}
	}
}