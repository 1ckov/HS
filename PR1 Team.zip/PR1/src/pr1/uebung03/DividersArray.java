package pr1.uebung03;

import static pr.MakeItSimple.*;

public class DividersArray {
	public static void main(String[] args) {
		
		println("Geben Sie eine natürliche Zahl an: ");
		int zahl = readInt();
		if(zahl < 0){
			print("Ungültige Eingabe");
			return;
		}
		int[] dividers = new int[35];
		int divisor = 1;
		int counter = 0;
		
		while(divisor<=zahl){
			if((zahl%divisor) == 0){
				
				dividers[counter] = divisor;
				counter++;

			}
			divisor++;
		}
		
		for(int i=0; i<dividers.length; i++) {
			if(dividers[i] > 0){
			print(dividers[i]+" ");
			}
		}
		
	}
}
