package pr1.uebung03;

import static pr.MakeItSimple.*;

public class Dividers {
	public static void main(String[] args) {

		println("Geben Sie eine natürliche Zahl an: ");
		int zahl = readInt();
		if (zahl < 0) {
			print("Ungültige Eingabe");

		} else {
			int divisor = 1;

			while (divisor <= zahl) {
				if ((zahl % divisor) == 0) {
					print(divisor + " ");
				}
				divisor++;
			}
		}
	}

}
