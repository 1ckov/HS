package pr1.uebung02;

import static pr.MakeItSimple.*;

public class BmiCalculator {
	public static void main(String[] args) {
		
		println("Gewicht der Person in KG:");
		double gewicht = readDouble();
		if (gewicht <30 || gewicht >300){
			println("Ungültige Eingabe!");
			return;
		}
		println("Männlich oder Weiblich?: ");
		String geschlecht = readString();
		println("Körpergröße der Person in Meter: ");
		double körpergröße = readDouble();
		if (körpergröße <1.2 || körpergröße >2.5){
			println("Ungültige Eingabe!");
			return;
		}
		double bmi = gewicht / (körpergröße * körpergröße);
		String meldung ="Test";
		int maxbmi = 0;
		int minbmi = 0;
		if (geschlecht.equals("weiblich")) {
			 minbmi = 19;
			 maxbmi = 24;
		} else if (geschlecht.equals("männlich")) {
			 minbmi = 20;
			 maxbmi = 25;
		}
		if(bmi>maxbmi){
			meldung = "zu fett";
		}
		else if(bmi<minbmi){
			meldung= "zu dünn";
		}
		else if(bmi>minbmi && bmi<maxbmi){
			meldung = "normal";
		}
		println("BMI: "+ bmi +" Sie sind " + meldung);
	}

}
