package pr1.uebung02;


import static pr.MakeItSimple.*;

public class BloodAlcoholContentWatson  {
	public static void main(String[] args) {
		println("männlich oder weiblich?: ");
		String geschlecht = readString();
		println("Gewicht der Person in KG: ");
		double gewicht = readDouble();
		println("Größe der Person in cm: ");
		double koerpergroeße = readDouble();
		println("Alter der Person: ");
		int alter = readInt();
		println("Getrunkener Alkohol in Gramm: ");
		double alkohol = readDouble();
		double gkw = 0;
		
		if (geschlecht.equals("weiblich")) {
			gkw = -2.097+0.1069*koerpergroeße+0.2466*gewicht;
		}
		else if(geschlecht.equals("männlich")){
			gkw = 2.447-0.09516*alter+0.1074*koerpergroeße+0.3362*gewicht;
		}
		
		
		double reduktionsfaktor = (1.055*gkw)/(0.8*gewicht);
		double bak = alkohol/(gewicht*reduktionsfaktor);
		println("Blutalkoholkonzentration: "+bak);

}
	}