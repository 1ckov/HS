package pr1.uebung02;

import static pr.MakeItSimple.*;

public class BloodAlcoholContent {
	public static void main(String[] args) {
		println("männlich oder weiblich?: ");
		String geschlecht = readString();
		println("Gewicht der Person in KG: ");
		double gewicht = readDouble();
		println("Getrunkener Alkohol in Gramm: ");
		double alkohol = readDouble();
		println("Blutalkoholgehalt der Person: ");
		double reduktionsfaktor  = 0;
		if (geschlecht.equals("weiblich")) {
		reduktionsfaktor = 0.6;
		}
		else if(geschlecht.equals("männlich")){
			reduktionsfaktor = 0.7;
		}
		
		double bak = alkohol/(gewicht*reduktionsfaktor);
		println(bak);
	}
}
