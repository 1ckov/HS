package pr1.uebung04;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class TicTacToe extends JFrame {

	private static final String EMPTY  = "";
	private static final String CROSS  = "X";
	private static final String CIRCLE = "O";
	private String currentSymbol = CROSS;
	private JButton[][] fields;

	TicTacToe() {
		super("Tic Tac Toe");
		setLayout(new GridLayout(3, 3));
		fields = new JButton[3][3];
		for (int row = 0; row < fields.length; row++) {
			for (int col = 0; col < fields[row].length; col++) {
				fields[row][col] = new JButton(EMPTY);
				fields[row][col].setFont(new java.awt.Font("Dialog", java.awt.Font.BOLD,12));
				fields[row][col].addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						((JButton) e.getSource()).setText(currentSymbol);
						if (succeeded(fields[0][0].getText(), fields[0][1].getText(), fields[0][2].getText(), fields[1][0].getText(), fields[1][1].getText(), fields[1][2].getText(), fields[2][0].getText(), fields[2][1].getText(), fields[2][2].getText())) {
							JOptionPane.showMessageDialog(TicTacToe.this, "Spieler '" + currentSymbol + "' hat gewonnen", "Gewonnen!", JOptionPane.INFORMATION_MESSAGE);
							System.exit(0);
						} else if (draw(fields[0][0].getText(), fields[0][1].getText(), fields[0][2].getText(), fields[1][0].getText(), fields[1][1].getText(), fields[1][2].getText(), fields[2][0].getText(), fields[2][1].getText(), fields[2][2].getText())) {
							JOptionPane.showMessageDialog(TicTacToe.this, "Das Spiel endete leider unentschieden", "Unentschieden!", JOptionPane.INFORMATION_MESSAGE);
							System.exit(0);
						} else {
							toggleSymbol();
						}
					}
				});
				add(fields[row][col]);
			}
		}
		
		setSize(1500, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	void toggleSymbol () {
		if (currentSymbol.equals(CROSS))
			currentSymbol = CIRCLE;
		else
			currentSymbol = CROSS;
	}
	
	static boolean succeeded(String topLeft, String topCenter, String topRight, String middleLeft, String middleCenter, String middleRight, String bottomLeft, String bottomCenter, String bottomRight) {
		if((topLeft.equals("X")  && middleLeft.equals("X")  && bottomLeft.equals("X") ) || (topLeft == "O" && middleLeft == "O" && bottomLeft == "O"))
		{
			return true;
		}
		if((topCenter.equals("X")  && middleCenter.equals("X")  && bottomCenter.equals("X") ) || (topCenter.equals("O")  && middleCenter.equals("O") && bottomCenter.equals("O")))
		{
			return true;
		}
		if((topRight.equals("X")  && middleRight.equals("X")  && bottomRight.equals("X") ) || (topRight.equals("O") && middleRight.equals("O") && bottomRight.equals("O")))
		{
			return true;
		}
		if((topLeft.equals("X")  && topCenter.equals("X")  && topRight.equals("X") ) || (topLeft.equals("O") && topCenter.equals("O") && topRight.equals("O")))
		{
			return true;
		}
		if((middleLeft.equals("X")  && middleCenter.equals("X")  && middleRight.equals("X") ) || (middleLeft.equals("O") && middleCenter.equals("O") && middleRight.equals("O")))
		{
			return true;
		}
		if((bottomLeft.equals("X")  && bottomCenter.equals("X")  && bottomRight.equals("X") ) || (bottomLeft.equals("O") && bottomCenter.equals("O") && bottomRight.equals("O")))
		{
			return true;
		}
		if((bottomLeft.equals("X")  && middleCenter.equals("X")  && topRight.equals("X") ) || (bottomLeft.equals("O") && middleCenter.equals("O") && topRight.equals("O")))
		{
			return true;
		}
		if((topLeft.equals("X")  && middleCenter.equals("X")  && bottomRight.equals("X") ) || (topLeft.equals("O") && middleCenter.equals("O") && bottomRight.equals("O")))
		{
			return true;
		}
		
		return false;
	}

	static boolean draw(String topLeft, String topCenter, String topRight, String middleLeft, String middleCenter, String middleRight, String bottomLeft, String bottomCenter, String bottomRight) {
		
		if((topLeft.equals("X")  || topLeft.equals("O")) && (topCenter.equals("X")  || topCenter.equals("O")) && (topRight.equals("X")  || topRight.equals("O")) && (middleLeft.equals("X")  || middleLeft.equals("O")) && (middleCenter.equals("X")  || middleCenter.equals("O")) && (middleRight.equals("X")  || middleRight.equals("O")) && (bottomLeft.equals("X")  || bottomLeft.equals("O")) && (bottomCenter.equals("X")  || bottomCenter.equals("O")) && (bottomRight.equals("X")  || bottomRight.equals("O")))
		{
			return !succeeded(topLeft, topCenter, topRight, middleLeft, middleCenter, middleRight, bottomLeft, bottomCenter, bottomRight);
		}
		else
		return false;
	}

	public static void main(String[] args) {
		new TicTacToe().setVisible(true);
	}

}