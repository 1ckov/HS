package pr1.uebung04;

import static pr.MakeItSimple.*;


public class SearchInRandomNumbers {
	public static int[] generate(int numberCount){
		if(numberCount < 0){
			throw new PRException("ungültige Eingabe: negative Zahl");
		}
		
		int[] arrayWithRandomNumbers = new int[numberCount];
		for(int i = 0; i < arrayWithRandomNumbers.length; i++){
			int randomNumber = (int) (Math.random()*1000) +1;
			//println(randomNumber);
			arrayWithRandomNumbers[i] = randomNumber;
			
		}
		
		
		return arrayWithRandomNumbers;
	}
	public static int[] searchAll(int[] arrayWithRandomNumbers, int numberToSearch){
		int countPositions = 0;
		for(int i = 0; i < arrayWithRandomNumbers.length; i++){
			
			if(arrayWithRandomNumbers[i]==numberToSearch){
				countPositions++;
			}

		}
		int[] positions = new int[countPositions];
		int counter = 0;
		for(int i = 0; i < arrayWithRandomNumbers.length; i++){
			
			if(arrayWithRandomNumbers[i]==numberToSearch){
				positions[counter] = i;
				counter++;
			}

		}
		return positions;
	}
	
	public static int searchLast(int[] arrayWithRandomNumbers, int numberToSearch){
		int lastPosition = -1;
		int i = 0;
		while(i < arrayWithRandomNumbers.length)
		{

			if(arrayWithRandomNumbers[i]==numberToSearch){
				lastPosition = i;
			}
			i++;
		}
		if(lastPosition == -1){
			throw new PRException("numberToSearch konnte in arrayWithRandomNumbers nicht gefunden werden");
		}



		return lastPosition;
	}

	public static void main(String[] args) {
		println("numberCount: ");
		int numberCount = readInt();
		println("numberToSearch: ");
		int numberToSearch = readInt();

		int[] arrayWithRandomNumbers = generate(numberCount);
		int[] positions = searchAll(arrayWithRandomNumbers, numberToSearch);

		println("Positionen: ");

		for(int i = 0; i < positions.length; i++){

			print(positions[i] + ", ");

		}

		println("letzte Position: " + searchLast(arrayWithRandomNumbers, numberToSearch));

	}

}
