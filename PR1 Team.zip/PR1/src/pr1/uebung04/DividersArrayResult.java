package pr1.uebung04;

import static pr.MakeItSimple.*;


public class DividersArrayResult {
	
	public static int[] calculateDividers(int zahl){
		int[] dividers = new int[35];
		int divisor = 1;
		int counter = 0;
		
		while(divisor<=zahl){
			if((zahl%divisor) == 0){
				
				dividers[counter] = divisor;
				counter++;

			}
			divisor++;
		}
		
		return dividers;
	}
	
	static boolean isPrime(int zahl) {
		
		int divisor = 1;
		int counter = 0;
		
		while(divisor<=zahl){
			if((zahl%divisor) == 0){
				
				counter++;

			}
			divisor++;
		}
		
		
		
		
		return counter<=2;
		
		
	}
	
	public static void main(String[] args) {
		

		
		println("Geben Sie eine natürliche Zahl an: ");
		int zahl = readInt();
		if(zahl < 0){
			print("Ungültige Eingabe");
		}
		else{
			int[] dividers = calculateDividers(zahl);
			
			for(int i=0; i<dividers.length; i++) {
				if(dividers[i] > 0){
				print(dividers[i]+" ");
				}
			}
			
			if (isPrime(zahl))
				println("Primzahl");
			else
				println("keine Primzahl");
			
		}
	}

}
