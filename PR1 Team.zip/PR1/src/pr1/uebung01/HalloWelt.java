package pr1.uebung01;

import static pr.MakeItSimple.*;

public class HalloWelt {
	
	public static void main(String[] args) {
		println("Hello World");
	}

}