package pr1.uebung01;

import static pr.MakeItSimple.*;

public class HelloWorld {
	
	public static void main(String[] args) {
		println("Hello World");
	}

}
