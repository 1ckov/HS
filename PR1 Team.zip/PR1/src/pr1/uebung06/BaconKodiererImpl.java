package pr1.uebung06;

import static pr.MakeItSimple.*;

import pr.MakeItSimple.PRException;

public class BaconKodiererImpl {
	public static void main(String[] args) {
		/*
		 * f) String nachricht = "Treffen uns um drei Uhr am Bahnhof!"; String
		 * traegerMedium = "Mein Name ist Juan Sanchez Villa-Lobos Ramirez, " +
		 * "oberster Metallurge am Hofe König Karl V. von Spanien;" +
		 * "ich wurde 896 vor Christus in Ägypten geboren und bin unsterblich seit 846 vor Christus"
		 * ; println(versteckeNachricht(nachricht, traegerMedium));
		 * println(zeigeNachricht(versteckeNachricht(nachricht,
		 * traegerMedium)));
		 */

		boolean showMenu = true;
		while (showMenu) {

			println("1 = Botschaft verstecken");
			println("2 = Botschaft sichtbar machen");
			println("3 = Demo");
			println("4 = Programm beenden");
			println("Geben Sie eine Zahl ein: ");
			int auswahl = readInt();

			switch (auswahl) {
			case 1:
				println("Geben Sie eine Nachricht ein: ");
				String nachricht = readString();
				println("Geben Sie ein Trägermedium ein: ");
				String traegerMedium = readString();
				println("Steganogramm: ");
				println(versteckeNachricht(nachricht, traegerMedium));
				break;
			case 2:
				println("Geben Sie ein Steganogramm ein: ");
				String steganogramm = readString();
				println("Nachricht: ");
				println(zeigeNachricht(steganogramm));
				break;
			case 3:
				println("Zu verschlüsselnde Nachricht: ");
				nachricht = "Wikipedia";
				println(nachricht);
				println("Trägermedium: ");
				traegerMedium = "Dies ist eine fast unauffällige Nachricht, oder etwa nicht?";
				println(traegerMedium);
				println("Nachricht wird bereinigt: ");
				println(reinigeNachricht(nachricht));
				println("Nachricht wird kodiert: ");
				println(kodiereNachricht(reinigeNachricht(nachricht)));
				println("verstecke Nachricht in Trägermedium: ");
				println(versteckeNachricht(nachricht, traegerMedium));
				println("dekodiere Nachricht: ");
				println(zeigeNachricht(versteckeNachricht(nachricht, traegerMedium)));
				break;
			case 4:
				showMenu = false;
				break;
			}
		}

	}

	static String reinigeNachricht(String nachricht) {
		nachricht = nachricht.replaceAll("ö", "oe");
		nachricht = nachricht.replaceAll("ä", "ae");
		nachricht = nachricht.replaceAll("ü", "ue");
		nachricht = nachricht.replaceAll("Ö", "Oe");
		nachricht = nachricht.replaceAll("Ü", "Ue");
		nachricht = nachricht.replaceAll("Ä", "Ae");
		nachricht = nachricht.replaceAll("ß", "SS");
		nachricht = nachricht.replaceAll("!", "");
		nachricht = nachricht.replaceAll("\\.", "");
		nachricht = nachricht.replaceAll(",", "");
		nachricht = nachricht.replaceAll(";", "");
		nachricht = nachricht.replaceAll(" ", "");
		nachricht = nachricht.replaceAll("\\?", "");
		nachricht = nachricht.replaceAll("\\\\", "");
		nachricht = nachricht.replaceAll("\\/", "");
		nachricht = nachricht.replaceAll("\\&", "");
		nachricht = nachricht.replaceAll("\\$", "");
		nachricht = nachricht.toUpperCase();

		return nachricht;
	}

	static String kodiereNachricht(String gereinigteNachricht) {
		char[] nachricht = gereinigteNachricht.toCharArray();
		for (int i = 0; i < nachricht.length; i++) {
			if (nachricht[i] < 'A' || nachricht[i] > 'Z') {
				throw new PRException("Ungültige Eingabe!");
			}
		}
		gereinigteNachricht = gereinigteNachricht.replaceAll("A", "kkkkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("B", "kkkkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("C", "kkkgk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("D", "kkkgg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("E", "kkgkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("F", "kkgkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("G", "kkggk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("H", "kkggg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("I", "kgkkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("J", "kgkkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("K", "kgkkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("L", "kgkgk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("M", "kgkgg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("N", "kggkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("O", "kggkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("P", "kgggk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("Q", "kgggg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("R", "gkkkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("S", "gkkkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("T", "gkkgk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("U", "gkkgg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("V", "gkkgg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("W", "gkgkk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("X", "gkgkg");
		gereinigteNachricht = gereinigteNachricht.replaceAll("Y", "gkggk");
		gereinigteNachricht = gereinigteNachricht.replaceAll("Z", "gkggg");

		return gereinigteNachricht;
	}

	static String dekodiereNachricht(String binaerCode) {
		int laenge = binaerCode.length();
		int fuenferblocke = laenge / 5;
		String[] teile = new String[fuenferblocke];

		for (int i = 0; i < teile.length; i++) {
			teile[i] = binaerCode.substring((i * 5), ((i + 1) * 5));
		}
		binaerCode = "";
		for (int i = 0; i < teile.length; i++) {
			teile[i] = teile[i].replaceAll("kkkkk", "A");
			teile[i] = teile[i].replaceAll("kkkkg", "B");
			teile[i] = teile[i].replaceAll("kkkgk", "C");
			teile[i] = teile[i].replaceAll("kkkgg", "D");
			teile[i] = teile[i].replaceAll("kkgkk", "E");
			teile[i] = teile[i].replaceAll("kkgkg", "F");
			teile[i] = teile[i].replaceAll("kkggk", "G");
			teile[i] = teile[i].replaceAll("kkggg", "H");
			teile[i] = teile[i].replaceAll("kgkkk", "I");
			teile[i] = teile[i].replaceAll("kgkkg", "K");
			teile[i] = teile[i].replaceAll("kgkgk", "L");
			teile[i] = teile[i].replaceAll("kgkgg", "M");
			teile[i] = teile[i].replaceAll("kggkk", "N");
			teile[i] = teile[i].replaceAll("kggkg", "O");
			teile[i] = teile[i].replaceAll("kgggk", "P");
			teile[i] = teile[i].replaceAll("kgggg", "Q");
			teile[i] = teile[i].replaceAll("gkkkk", "R");
			teile[i] = teile[i].replaceAll("gkkkg", "S");
			teile[i] = teile[i].replaceAll("gkkgk", "T");
			teile[i] = teile[i].replaceAll("gkkgg", "U");
			teile[i] = teile[i].replaceAll("gkgkk", "W");
			teile[i] = teile[i].replaceAll("gkgkg", "X");
			teile[i] = teile[i].replaceAll("gkggk", "Y");
			teile[i] = teile[i].replaceAll("gkggg", "Z");

			if (teile[i].charAt(0) < 'A' || teile[i].charAt(0) > 'Z') {
				teile[i] = "#";
			}
			binaerCode = binaerCode + teile[i];
		}
		return binaerCode;
	}

	static String versteckeNachricht(String nachricht, String traegerMedium) {
		String gereinigteNachricht = reinigeNachricht(nachricht);
		String binaerCode = kodiereNachricht(gereinigteNachricht);
		String ergebnis = "";
		String tmp = "";
		if (traegerMedium.length() < binaerCode.length()) {
			throw new PRException("Traegermedium zu kurz");
		}
		int i = 0;
		int k = 0;

		while (i < traegerMedium.length()) {
			if (k < binaerCode.length()) {
				if (binaerCode.charAt(k) == 'g'
						&& ((traegerMedium.charAt(i) >= 'A' && traegerMedium.charAt(i) <= 'Z')
								|| (traegerMedium.charAt(i) >= 'a' && traegerMedium.charAt(i) <= 'z'))
						|| traegerMedium.charAt(i) == 'ö' || traegerMedium.charAt(i) == 'ä'
						|| traegerMedium.charAt(i) == 'ü') {
					tmp = tmp + traegerMedium.charAt(i);
					ergebnis = ergebnis + tmp.toUpperCase();
					tmp = "";
					k++;
					i++;
				} else if (binaerCode.charAt(k) == 'k'
						&& ((traegerMedium.charAt(i) >= 'A' && traegerMedium.charAt(i) <= 'Z')
								|| (traegerMedium.charAt(i) >= 'a' && traegerMedium.charAt(i) <= 'z')
								|| traegerMedium.charAt(i) == 'Ö' || traegerMedium.charAt(i) == 'Ä')
						|| traegerMedium.charAt(i) == 'Ü') {
					tmp = tmp + traegerMedium.charAt(i);
					ergebnis = ergebnis + tmp.toLowerCase();
					tmp = "";
					k++;
					i++;
				} else {

					ergebnis = ergebnis + traegerMedium.charAt(i);
					i++;
				}
			} else {
				ergebnis = ergebnis + traegerMedium.charAt(i);
				i++;
			}

		}

		return ergebnis;
	}

	static String zeigeNachricht(String steganogramm) {
		String ergebnis = "";
		for (int i = 0; i < steganogramm.length(); i++) {
			if ((steganogramm.charAt(i) >= 'A' && steganogramm.charAt(i) <= 'Z') || steganogramm.charAt(i) == 'ö'
					|| steganogramm.charAt(i) == 'ä' || steganogramm.charAt(i) == 'ü' || steganogramm.charAt(i) == 'Ö'
					|| steganogramm.charAt(i) == 'Ä' || steganogramm.charAt(i) == 'ä'
					|| steganogramm.charAt(i) == 'Ü') {

				ergebnis = ergebnis + "g";
			} else if ((steganogramm.charAt(i) >= 'a' && steganogramm.charAt(i) <= 'z')) {
				ergebnis = ergebnis + "k";
			}
		}

		return dekodiereNachricht(ergebnis);
	}

}