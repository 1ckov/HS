package pr1.uebung06;

import static pr.MakeItSimple.*;

public class Calculator {

	public static void main(String[] args) {
//		println("Geben Sie eine Rechenaufgabe ein: ");
//		String rechenaufgabe = readString();
//		String[] formulaArray = analyzeFormula(rechenaufgabe);
//		for (int i = 0; i < formulaArray.length; i++) {
//			println(formulaArray[i]);
//		}
		
		String[] arr = new String[]{"1", "+", "1" , "+" , "2"};
		System.out.println(Calculator.calculate(arr));
	}

	public static String[] analyzeFormula(String formulaText) {
		String[] formulaArray = new String[100];

		formulaArray = formulaText.split(" ");

		return formulaArray;
	}

	public static int calculate(String[] elements) {
		int result = 0;
		int operand = 0;
		for (int i = 0; i < elements.length; i++) {
			if (!elements[i].equals("+") && !elements[i].equals("-")) {
				int tmp = Integer.parseInt(elements[i]);
				if (operand == 0) {
					result += tmp;
				} else {
					result -= tmp;
				}
			}
			if (elements[i].equals("+")) {
				operand = 0;
			}
			if (elements[i].equals("-")) {
				operand = 1;
			}

		}

		return result;
	}
}
