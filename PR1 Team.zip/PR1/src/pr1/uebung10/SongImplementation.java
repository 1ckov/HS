package pr1.uebung10;

import static pr.MakeItSimple.*;

public class SongImplementation implements Song, Comparable<Song> {
	private String SongName = "";
	private String AlbumName = "";
	private String[] Artists;

	public SongImplementation(String SongName, String AlbumName, String[] Artists) {
		if (SongName == "") {
			throw new PRException("Das ist kein Gueltiger name! ");
		} else {
			this.SongName = SongName;
		}
		if (AlbumName == "") {
			throw new PRException("Das ist kein gueltiger Album Name! ");
		} else {
			this.AlbumName = AlbumName;
		}
		boolean areThereArtists = false;
		for (int i = 0; i < Artists.length; i++) {
			if (Artists[i] == "") {
				throw new PRException("Das ist kein gueltiger Kunstler Name! ");
			}
			areThereArtists = true;
		}
		if (areThereArtists) {
			this.Artists = Artists;
		}
	}

	@Override
	public String getSongName() {
		return this.SongName;
	}

	@Override
	public String getAlbumName() {
		return this.AlbumName;
	}

	@Override
	public String[] getArtists() {
		return this.Artists;
	}

	@Override
	public String toString() {
		String songInfo = "";
		String artistsHelp = "";
		
		for (int i = 0; i < Artists.length; i++) {
			if (i < Artists.length - 1) {
				artistsHelp += Artists[i] + " & ";
			}
			else{
				artistsHelp += Artists[i];
			}
		}
		
		songInfo = "Song Name: " + this.SongName + ";\n" + "Artist Name:  " + artistsHelp + ";\n" + "Album Name: "
				+ this.AlbumName + "; ";
		return songInfo;

	}

	@Override
	public int compareTo(Song o) {
		// return this.toString().compareTo(o.toString());
		String otherSong = o.getSongName();
		String thisSong = this.getSongName();
		for (int i = 0; i < otherSong.length(); i++) {
			// Falls current naeher a ist
			if (thisSong.charAt(i) < otherSong.charAt(i)) {
				return -1;
			}
			// falls Buchstabe groesser
			else if (thisSong.charAt(i) > otherSong.charAt(i)) {
				return 1;
			}
		}
		return 0;

	}

}
