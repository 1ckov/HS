package pr1.uebung10;

import static pr.MakeItSimple.*;

import pr1.uebung07.StringExtension;

public class TestClass {

	public static void main(String[] args) {
		String name = "Hello Darkness";
		String album = "Some Album";
		String[] artists = {"Simon", "Garfunkel"};
		String name1 = "Hallo Darkness";
		String album1 = "Same Albusdadm";
		String[] artists1 = {"Simson", "Garfunskel"};
		String name2 = "Hbllo Darkness";
		String album2 = "Soee Album";
		String[] artists2 = {"Simon", "Garfunkel"};
		Song third = new SongImplementation(name2,album2,artists2);
		Song second = new SongImplementation(name1,album1,artists1);
		Song first = new SongImplementation(name,album,artists);
		String test = first.getSongName();
		System.out.println(test);
		OrderedList liste = new LinkedList();
		liste.insert(first);
		liste.insert(second);
		liste.insert(third);
		liste.insert(second);
		System.out.println((liste.get(3)).toString());
		
		String[] testContent = readStringArray("src/pr1/uebung10/U10 songs.txt");
		System.out.println(testContent[0]);
		String[] Song1 = StringExtension.split(testContent[0], ';');
		System.out.println(Song1[0]);
		

	}

}
